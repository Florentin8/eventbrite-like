# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
EventbriteLike::Application.config.secret_token = 'fa89c1623818f2fa6c5768ba255b4f0b688d86ebfa9034c012e6453dee3fea714949463ebe7d215f06f8355dce7764de27b22ddfaaab128ff6de40ade852326f'
